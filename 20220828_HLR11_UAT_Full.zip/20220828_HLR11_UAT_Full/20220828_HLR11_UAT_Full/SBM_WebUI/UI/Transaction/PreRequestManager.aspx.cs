﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Claim;
using SBM_BLC1.Entity.Common;
using CrystalDecisions.Enterprise;
using SBM_BLC1.Transaction;
using SBM_BLV1;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Common;

namespace SBM_WebUI.mp
{
    public partial class PreRequestManager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Constants.SES_USER_CONFIG] != null)
            {
                if (!Page.IsPostBack)
                {
                    Util.InvalidateSession();
                    InitializeData();
                    //This is for Page Permission
                    CheckPermission chkPer = new CheckPermission();
                    Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    if (!chkPer.CheckPagePermission((Control)this.Page, oConfig, (int)Constants.PAGEINDEX_TRANS.SP_ISSUE_VIEW))
                    {
                        Response.Redirect(Constants.PAGE_ERROR, false);
                    }
                    else if (oConfig.UserRole.Contains("HO"))
                    {
                        Response.Redirect(Constants.PAGE_ERROR, false);
                    }
                    //End Of Page Permission

                }
            }
            else
            {
                Response.Redirect(Constants.PAGE_LOGIN, false);
            }
        }

        protected void InitializeData()
        {
            DDListUtil.LoadDDLFromDB(ddlSpType, "SPTypeID", "TypeDesc", "SPMS_SPType", true);

            DataTable dt1 = new DataTable();
            gvTransactionList.DataSource = dt1;
            gvTransactionList.DataBind();
        }
        public void PopErrorMsgAction(string sType)
        {
            if (sType.Equals(Constants.BTN_APPROVE) || sType.Equals(Constants.BTN_REJECT))
            {
                Response.Redirect(Constants.PAGE_TRAN_APPROVAL + "?pType=" + Convert.ToString((int)Constants.PAGEINDEX_TRANS.SP_ISSUE_UPDATE).PadLeft(5, '0'), false);
            }
            else
            {
                // no action
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSearchValue.Text))
            {
                if (ddlTransType.SelectedIndex > 0)
                {

                    Result oResult = null;
                    PreRequestManagerDAL prm = new PreRequestManagerDAL();

                    if (ddlTransType.SelectedValue != "S")
                    {
                        oResult = prm.Load_ViewPreReqDataSearch_List(ddlSpType.SelectedValue.ToString(), ddlTransType.SelectedValue.ToString(), txtSearchValue.Text);
                    }
                    if (oResult.Status)
                    {
                        gvTransactionList.DataSource = oResult.Return;
                        gvTransactionList.DataBind();
                    }
                    else
                    {
                        DataTable dt1 = new DataTable();
                        gvTransactionList.DataSource = dt1;
                        gvTransactionList.DataBind();
                    }
                }
                else
                {
                    DataTable dt2 = new DataTable();
                    gvTransactionList.DataSource = dt2;
                    gvTransactionList.DataBind();

                }
            }
            else
            {
                DataTable dt3 = new DataTable();
                gvTransactionList.DataSource = dt3;
                gvTransactionList.DataBind();
            }
        }

        protected void ddlTransType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //btnDeleteAll.Visible = false;
            //if (ddlTransType.SelectedIndex > 0)
            //{
            //    if (ddlTransType.SelectedValue == "I")
            //    {
            //        btnDeleteAll.Visible = true;
            //    }
            //}
        }


        protected void gvTransactionList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if ((e.Row.RowType == DataControlRowType.Header) || (e.Row.RowType == DataControlRowType.DataRow))
            {
                if ((e.Row.RowType == DataControlRowType.DataRow))
                {
                    for (int i = 0; i < e.Row.Cells.Count; i++)
                    {
                        e.Row.Cells[i].Wrap = true;
                        e.Row.Cells[i].BackColor = System.Drawing.Color.Silver;
                    }
                }
                e.Row.Cells[0].Width = new Unit("50px");
                e.Row.Cells[1].Width = new Unit("150px");
                e.Row.Cells[2].Width = new Unit("75px");
                e.Row.Cells[3].Width = new Unit("50px");
                e.Row.Cells[4].Width = new Unit("130px");
                e.Row.Cells[5].Width = new Unit("100px");
                e.Row.Cells[6].Width = new Unit("100px");
                e.Row.Cells[7].Width = new Unit("100px");
                e.Row.Cells[8].Width = new Unit("145px");
            }
        }
        protected void gvTransactionList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "NewReq")
            {
                CryptographyManager oCrypManager = new CryptographyManager();
                GridViewRow gvRow = (GridViewRow)((Button)e.CommandSource).NamingContainer;

                string sType = "0" + Convert.ToString((int)Constants.PAGEINDEX_TRANS.SP_ISSUE_UPDATE).Substring(0, 3) + "2";
                if (ddlRequestType.SelectedValue == "I")
                {

                    //if (ddlSpType.SelectedValue == "DPB" || ddlSpType.SelectedValue == "DIB") //ddlSpType.SelectedValue == "WDB" || 
                    //{
                    //    string urlRef =Constants.PAGE_TRAN_ISSUE + "?sRegID=" + oCrypManager.GetEncryptedString(gvRow.Cells[1].Text) + "&sPageID=" + oCrypManager.GetEncryptedString(sType);
                    //    //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));
                        
                    //    string OpenWindow = "window.open('" + urlRef + "','','')";
                    //    ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
                    //}
                    //else
                    //{
                    //    string urlRef = Constants.PAGE_TRAN_ISSUE_ONLINE + "?sRegID=" + oCrypManager.GetEncryptedString(gvRow.Cells[1].Text) + "&sPageID=" + oCrypManager.GetEncryptedString(sType);
                    //    //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));
                    //    string OpenWindow = "window.open('" + urlRef + "','','')";
                    //    ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
                    //}
                    string urlRef = Constants.PAGE_TRAN_ISSUE_ONLINE + "?sRegID=" + oCrypManager.GetEncryptedString(gvRow.Cells[1].Text) + "&sPageID=" + oCrypManager.GetEncryptedString(sType);
                    //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));
                    string OpenWindow = "window.open('" + urlRef + "','','')";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
                }
                else if (ddlRequestType.SelectedValue == "P")
                {
                    string urlRef = Constants.PAGE_TRAN_INTPAYMENT + "?sRegNo=" + oCrypManager.GetEncryptedString(gvRow.Cells[1].Text) + "&sPageID=" + oCrypManager.GetEncryptedString(sType);
                    //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));
                    string OpenWindow = "window.open('" + urlRef + "','','')";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
                }
                else if (ddlRequestType.SelectedValue == "E")
                {
                    string urlRef = Constants.PAGE_TRAN_ENCASHMENT + "?sRegNo=" + oCrypManager.GetEncryptedString(gvRow.Cells[1].Text) + "&sPageID=" + oCrypManager.GetEncryptedString(sType);
                    //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));
                    string OpenWindow = "window.open('" + urlRef + "','','')";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
                }
                else if (ddlRequestType.SelectedValue == "R")
                {
                    string urlRef = Constants.PAGE_TRAN_REINVESTMENT + "?sRegNo=" + oCrypManager.GetEncryptedString(gvRow.Cells[1].Text) + "&sPageID=" + oCrypManager.GetEncryptedString(sType);
                    string OpenWindow = "window.open('" + urlRef + "','','')";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
                }

                else if (ddlRequestType.SelectedValue == "L")
                {
                    //string urlRef = Constants.PAGE_TRAN_LIEN_MARK + "?qRegNo=" + oCrypManager.GetEncryptedString(gvRow.Cells[1].Text);
                    //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));
                }
            }
        }

        protected void btnNewPreRequest_Click(object sender, EventArgs e)
        {

            if (ddlSpType.SelectedValue == "")
            {
                //ucMessage.OpenMessage("Please select a valid SP/BOND Type.", Constants.MSG_TYPE_ERROR);
                return;
            }
            if (ddlSpType.SelectedValue == "DPB" || ddlSpType.SelectedValue == "DIB") //ddlSpType.SelectedValue == "WDB" || 
            {
                string urlRef = Constants.PAGE_TRAN_ISSUE;
                //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));

                string OpenWindow = "window.open('" + urlRef + "','','')";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
            }
            else
            {
                string urlRef = Constants.PAGE_TRAN_ISSUE_ONLINE;
                //Page.RegisterStartupScript(Constants.PAGE_WINDOW, Util.OpenViewIssue(urlRef));
                string OpenWindow = "window.open('" + urlRef + "','','')";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "OpenWindow", OpenWindow, true);
            }
        }

    }
    }
